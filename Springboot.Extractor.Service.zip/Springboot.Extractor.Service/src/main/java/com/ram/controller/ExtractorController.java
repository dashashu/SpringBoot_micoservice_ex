package com.ram.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;

import org.apache.commons.lang3.StringUtils;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.pdf.PDFParser;
import org.apache.tika.sax.BodyContentHandler;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ram.model.DataDetailsDTO;
import com.ram.model.Patient;
import com.ram.services.RulesUtils;



/*
 * This is the Service Extractor:
 * Here it get the pdf for the uuid and extract the data from the PDF .
 *  And send post request to another Transformer service with a json data.*/
@RestController
public class ExtractorController
{
//	@Value("#{'${MSI.Report.headers}'.split(',')}") 
//	List<String> MSIReport; 
//	@Value("${TMB.Report.headers}")
//	private List<String> TMBReport ;
//	@Value("${MSI.result.headers}")
//	private List<String> MSIResult ;
//	@Value("${TMB.unit.headers}")
//	private List<String> MSIPostfix;
//	@Value("${Patient.details.headers}")
//	private List<String> Patient;
	
	@PostMapping("/Extractor")
    public void download(@RequestParam("uuid") String uuid) throws IOException {
		
		//List<String> Patient = Arrays.asList("name:","date of birth:","sex:","case number:");
		List<String> MSIReport = Arrays.asList("MSI","MSI-","MSI status","MSI Status","MSI status","Microsatellite","MicrosatelliteInstability","Microsatellite Instability");
		List<String> TMBReport = Arrays.asList("TMB","Tumor Mutational Burden","TMB Status","TMB status");
		List<String> MSIResult = Arrays.asList("Stable","stable","STABLE","High","high "," high","HIGH","LOW","Low","low");
		List<String> MSIPostfix = Arrays.asList("mut/Mb","Muts/Mb §","Mutations/Mb","mut/Mb","Muts/Mb");
		
		System.out.println("::::::EXTRACTOR SERVICE::::::");
		System.out.println("\n"+"Received UUID from Controller is "+uuid+'\n');
		String filename = "";
		File dir = new File("C:\\FileStore\\");
		for(File file : dir.listFiles()) {
		    if(file.getName().startsWith(uuid)) {
		    	filename = file.getName();
		    }
		}

		System.out.println("\n"+"Extracting the file with the uuid:"+filename+'\n');
		try {
			BodyContentHandler handler = new BodyContentHandler();
		      Metadata metadata = new Metadata();
		      FileInputStream inputstream = new FileInputStream(new File(dir+"\\"+filename));
		      ParseContext pcontext = new ParseContext();
		 
		      PDFParser pdfparser = new PDFParser(); 
		      pdfparser.parse(inputstream, handler, metadata,pcontext);
		      
		      FileWriter PDFWriter = new FileWriter("C:\\Users\\223055789\\Desktop\\PDF Report\\PDFData.txt");
		      PDFWriter.write(handler.toString());
		      PDFWriter.close();
	        
	        FileWriter fWriter = new FileWriter("C:\\Users\\223055789\\Desktop\\PDF Report\\PDFMetadata.txt");
	        
	        String[] metadatas = metadata.names();   
	        for(String data : metadatas) {  
	            fWriter.write(data + ":   "+ metadata.get(data)+'\n');
	        }  
	        fWriter.close();
		}catch (Exception e){
			System.out.println(e);
		}

		File file = new File("C:\\Users\\223055789\\Desktop\\PDF Report\\PDFData.txt");
		Scanner input = new Scanner(file);
		
		RulesUtils rules = new RulesUtils();
		DataDetailsDTO data = rules.applyPreProcessingRule(MSIReport, TMBReport, input);
		
		rules.ExtractDataRule(data.getMicrosatelliteInstability(), data.getTumorMutationBurden());
		
		JSONObject PatientJson = new JSONObject();
		PatientJson.put(Patient.getMSIKey(),Patient.getMSIValue());
		PatientJson.put(Patient.getTMBKey(),Patient.getTMBValue());
				
		//give a push for transformer
		String url = "http://localhost:8082/Transformer";
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headerEx = new HttpHeaders();
		headerEx.setContentType(MediaType.APPLICATION_JSON);
		headerEx.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

		
		HttpEntity<String> request = new HttpEntity<String>(PatientJson.toString(), headerEx);
		ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
		if (response.getStatusCode() == HttpStatus.OK) {
		    System.out.println("Notification to Transformer Service is Successful");
		} else {
		    System.out.println("Notification to Transformer Service Failed");
		}
		  
    }
}

