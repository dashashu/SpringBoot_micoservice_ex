package com.ram.model;

public class Patient {
		private String FirstName;
		private String LastName;
	    private static String TMBKey = "TMB";
	    private static String TMBValue;
	    private static String MSIKey = "MSI";
		private static String MSIValue;
	    
	    public Patient( String TMBKey, String TMBValue, String MSIKey,String MTSValue,String MSIValue) {
	        //this.ID = ID;
	        this.TMBKey = TMBKey;
	        this.TMBValue = TMBValue;
	        this.MSIKey = MSIKey;
	        this.MSIValue = MSIValue;
	    }

		public static String getTMBKey() {
			return TMBKey;
		}

		public void setTMBKey(String tMBKey) {
			TMBKey = tMBKey;
		}

		public static String getTMBValue() {
			return TMBValue;
		}

		public static void setTMBValue(String tMBValue) {
			TMBValue = tMBValue;
		}

		public static String getMSIKey() {
			return MSIKey;
		}

		public void setMSIKey(String mSIKey) {
			MSIKey = mSIKey;
		}

		public static String getMSIValue() {
			return MSIValue;
		}

		public static void setMSIValue(String mSIValue) {
			MSIValue = mSIValue;
		}
	    






}
