package com.ram.model;

import java.util.HashMap;
import java.util.List;

public class DataDetailsDTO {
	private HashMap<String,List<String>> MicrosatelliteInstability;

    private HashMap<String,List<String>> TumorMutationBurden;

	public HashMap<String, List<String>> getMicrosatelliteInstability() {
		return MicrosatelliteInstability;
	}

	public void setMicrosatelliteInstability(HashMap<String, List<String>> microsatelliteInstability) {
		MicrosatelliteInstability = microsatelliteInstability;
	}

	public HashMap<String, List<String>> getTumorMutationBurden() {
		return TumorMutationBurden;
	}

	public void setTumorMutationBurden(HashMap<String, List<String>> tumorMutationBurden) {
		TumorMutationBurden = tumorMutationBurden;
	}

}
