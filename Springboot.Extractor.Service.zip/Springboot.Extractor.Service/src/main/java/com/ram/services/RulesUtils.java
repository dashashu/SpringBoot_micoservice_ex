package com.ram.services;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;

import org.apache.commons.lang3.StringUtils;

import com.ram.model.DataDetailsDTO;
import com.ram.model.Patient;
public class RulesUtils {
	List<String> MSIReport = Arrays.asList("MSI","MSI-","MSI status","MSI Status","MSI status","Microsatellite","MicrosatelliteInstability","Microsatellite Instability");
	List<String> TMBReport = Arrays.asList("TMB","Tumor Mutational Burden","TMB Status","TMB status");
	List<String> MSIResult = Arrays.asList("Stable","stable","STABLE","High","high "," high","HIGH","LOW","Low","low");
	List<String> MSIPostfix = Arrays.asList("mut/Mb","Muts/Mb §","Mutations/Mb","mut/Mb","Muts/Mb");
	public DataDetailsDTO applyPreProcessingRule(List<java.lang.String> MSIReport, List<java.lang.String> TMBReport,Scanner input) {
		HashMap<String,List<String>> MSIMap = new HashMap<>();
		HashMap<String,List<String>> TMBMap = new HashMap<>();
	//		if (line.contains(s)) {
	//		details.put(s,line.replace(s,"").trim());
	//		PatientData.put("Patient", details);
	//		}
	//	});
		List<String> MSIList = new ArrayList<String>();
		List<String> TMBList = new ArrayList<String>();
		while (input.hasNextLine()) {
			String line = input.nextLine();
			MSIReport.forEach(s->{// get the matching MSI status
				if (line.length()<60 && line.contains(s)) {
					if(MSIMap.containsKey(s)){
						MSIMap.get(s).add(line);
					}else {
						MSIList.add(line);
						MSIMap.put(s, MSIList);
					}
				}
			});

			TMBReport.forEach(s-> { // get the matching TMB number lines
				if(StringUtils.isNumericSpace(line.replaceAll("[^0-9]",""))&& line.contains(s) && MSIPostfix.stream().anyMatch(k -> line.contains(k))) {
						if(TMBMap.containsKey(s)){
							TMBMap.get(s).add(line.replaceAll("[^0-9]",""));
						}else {
							TMBList.add(line.replaceAll("[^0-9]",""));
							TMBMap.put(s, TMBList);
						}
					//}
				}
			});
		}
		DataDetailsDTO dataDetailsDTO = new DataDetailsDTO();
		dataDetailsDTO.setMicrosatelliteInstability(MSIMap);
		dataDetailsDTO.setTumorMutationBurden(TMBMap);
		return 	dataDetailsDTO;	
	}
	public  void ExtractDataRule(HashMap<String,List<String>> MSIMap,HashMap<String,List<String>> TMBMap){

		ArrayList<String> MSIres = new ArrayList<String>();
		//List<String> MSIres = Arrays.asList("unknown");
		for (Entry<String, List<String>> entry: MSIMap.entrySet()) {
			for(int i=0;i<entry.getValue().size();i++){
				for (int j=0;j<MSIResult.size();j++) {
					if(entry.getValue().get(i).contains(MSIResult.get(j))) {
						MSIres.add(MSIResult.get(j).toString());
					}
				}
			}
		}
		MSIres.replaceAll(String::toLowerCase);
		if(MSIres.stream().distinct().limit(2).count() <= 1) {
			Patient.setMSIValue(MSIres.get(0));
		}else {
			Patient.setMSIValue("unknown");
		}
		
		ArrayList<String> TMBres = new ArrayList<String>();
		for (Entry<String, List<String>> entry: TMBMap.entrySet()) {
			if(entry.getValue().stream().distinct().limit(2).count() <= 1) {
				Patient.setTMBValue(entry.getValue().get(0));
			}else {
				Patient.setTMBValue(entry.getValue().get(0));
			}
		}
	}
	
}
