package com.collector.controller;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;

import org.apache.http.conn.socket.LayeredConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.simple.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.collector.helper.UnsafeX509ExtendedTrustManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@RestController
public class TransformerController {
	@PostMapping(value ="/Transformer",consumes = "application/json", produces = "application/json")
		public void process(@RequestBody JSONObject payload) throws Exception {
		System.out.println("::::::TRANSFORMER SERVICE::::::");
		String CDIP_URL = "https://cdip-capra-gateway.cloud.health.ge.com/staging/fhir/r4/Observation/";
		
		String msi = (String) payload.get("MSI");
		String tmb = (String) payload.get("TMB"); 
		System.out.println( "\n"+"The payload recived from Extractor"+payload);
//		  For MSI
		  JsonObject MsiObject = null;
		  JsonObject TMBObject = null;
	        try (FileReader reader = new FileReader("C:\\Users\\223055789\\eclipse-workspace\\Springboot.Transformer.Service\\src\\main\\resources\\Observation-MicrosatelliteInstability.json"))
	        {
				JsonParser parser = new JsonParser();
				JsonElement jsonElement = parser.parse(reader);
				MsiObject = jsonElement.getAsJsonObject();
        	  	
	        	JsonElement firstSet = ((JsonObject) MsiObject.get("valueCodeableConcept")).get("coding").getAsJsonArray().get(0);
	        	firstSet.getAsJsonObject().addProperty("display",msi);
	        	System.out.println("\n"+"The MSI data sending to CDIP is : "+MsiObject);
	        }catch (Exception e) {
	        	System.out.println(e);
	        }
	      //for Tumor Mutational Burden
	        try (FileReader reader = new FileReader("C:\\Users\\223055789\\eclipse-workspace\\Springboot.Transformer.Service\\src\\main\\resources\\Observation-TumorMutationBurden.json"))
	        {
				JsonParser parser = new JsonParser();
				JsonElement jsonElement = parser.parse(reader);
				TMBObject = jsonElement.getAsJsonObject();
        	  	//((JsonObject) TMBObject.get("subject")).addProperty("reference", "Patient/"+pateintName);
	        	((JsonObject) TMBObject.get("valueQuantity")).addProperty("value", tmb);
	        	
        	System.out.println("\n"+"The Tumor Mutational Burden data sending to CDIP is : "+TMBObject);
	        }catch (Exception e) {
	        	System.out.println(e);
	        }
	        
		  //upload to CDIP server
		
		//To avoid SSL cert-fetch and add
		HostnameVerifier hostnameVerifier = (host, sslSession) -> true;
		TrustManager[] trustManagers = new TrustManager[]{UnsafeX509ExtendedTrustManager.getInstance()};

		SSLContext sslContext = SSLContext.getInstance("TLS");
		sslContext.init(null, trustManagers, null);
		LayeredConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext, hostnameVerifier);
		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).build();
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setHttpClient(httpClient);
		RestTemplate restTemplate = new RestTemplate(requestFactory);
		//HTTP call header set
		HttpHeaders headerEx = new HttpHeaders();
		headerEx.setContentType(MediaType.APPLICATION_JSON);
		headerEx.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		//adding the json objects to the entity for request bodt
		HttpEntity<String> entity1 = new HttpEntity<>(MsiObject.toString(), headerEx);
		HttpEntity<String> entity2 = new HttpEntity<>(TMBObject.toString(), headerEx);
		
		List<HttpEntity<String>> entityList = new ArrayList<HttpEntity<String>>();
		List<ResponseEntity<String>> responseList = new ArrayList<ResponseEntity<String>>();
		entityList.add(entity1);
		entityList.add(entity2);
		for(int i =0; i<= entityList.size()-1; i++) {
			ResponseEntity<String> response = restTemplate.postForEntity(CDIP_URL, entityList.get(i), String.class);
			responseList.add(response);
		}
		for (int i =0; i<= responseList.size()-1; i++) {
		    try {
		    	if(responseList.get(i).getStatusCode()== HttpStatus.CREATED){
		    		System.out.println("\n"+"Uploading data to CDIP is Successful "+i+ " request, Below is the response: ");
				    System.out.println(responseList.get(i).getBody());
				} else {
				    System.out.println("\n"+"Notification to CDIP Failed for" +i+ "with status "+responseList.get(i).getStatusCode());
				}
		     
		    } catch (Exception ex) {
		        throw new Exception("Exception while making Rest call.", ex);
		    }
		}
	}
}

