package com.collector.model;

public class Patient {
		private String FirstName;
		private String LastName;
	    private String TMBKey;
	    private String TMBValue;
	    private String MTSKEy;
		private String MTSValue;
	    
	    public Patient( String TMBKey, String TMBValue, String MTSKEy,String MTSValue) {
	        //this.ID = ID;
	        this.TMBKey = TMBKey;
	        this.TMBValue = TMBValue;
	        this.MTSKEy = MTSKEy;
	        this.MTSValue = MTSValue;
	    }
	    public String getTMBKey() {
			return TMBKey;
		}


		public void setTMBKey(String tMBKey) {
			TMBKey = tMBKey;
		}


		public String getTMBValue() {
			return TMBValue;
		}


		public void setTMBValue(String tMBValue) {
			TMBValue = tMBValue;
		}


		public String getMTSKEy() {
			return MTSKEy;
		}


		public void setMTSKEy(String mTSKEy) {
			MTSKEy = mTSKEy;
		}

		public String getMTSValue() {
			return MTSValue;
		}


		public void setMTSValue(String mTSValue) {
			MTSValue = mTSValue;
		}




}
