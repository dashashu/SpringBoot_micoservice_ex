package com.collector.controller;

import java.util.Arrays;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.collector.message.ResponseMessage;
import com.collector.service.FilesStorageService;
import com.collector.service.UuidCreator;



@Controller
public class CollectorController {

  @Autowired
  FilesStorageService storageService;

  @PostMapping("/Collector")
  public ResponseEntity<ResponseMessage> uploadFile(@RequestParam("file") MultipartFile file) {
	System.out.println("::::::COLLECTOR SERVICE::::::");
	String message = "";
	UuidCreator obj = new UuidCreator();
	UUID uuid = obj.getUUID();
	String ExtractorUrl = "http://localhost:8081/Extractor?uuid="+uuid;
	System.out.println("\n"+"received PDF File is "+file.getOriginalFilename());
	System.out.println("\n"+"Generated UUID is for the  file is: "+ uuid);
    try {
	storageService.save(file,uuid.toString());
	message = "Uploaded the file successfully: " + file.getOriginalFilename();
      
	HttpHeaders headers = new HttpHeaders();
	headers.setAccept(Arrays.asList(new MediaType[] { MediaType.APPLICATION_PDF ,MediaType.APPLICATION_OCTET_STREAM //convert pdf to byte stream
	}));
	
	headers.setContentType(MediaType.APPLICATION_OCTET_STREAM );
	headers.set("my_other_key", "my_other_value");
	HttpEntity<Object[]> request = new HttpEntity<Object[]>(headers);
	// RestTemplate
	RestTemplate restTemplate = new RestTemplate();
      // Send the request body in HttpEntity for HTTP POST request to Extractor service
      ResponseEntity<String> productCreateResponse = restTemplate.exchange(ExtractorUrl, HttpMethod.POST, request, String.class);
      
      if(productCreateResponse.getStatusCode() == HttpStatus.OK) {
    	  message = message+ " and Also informed to Extractor wtih the uuid";
    	  System.out.println("\n"+"File uploaded to Filestore with UUID:"+uuid+"\n"+"\n"+"Notification to the Extractor service is Successful");
      }
      else {
    	  System.out.println("Notification to Extractor Failed");
      }
      return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
    } catch (Exception e) {
      message = "Could not upload the file: " + file.getOriginalFilename() + "!"+"Exception: "+e;
      return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
    }
  }

}
