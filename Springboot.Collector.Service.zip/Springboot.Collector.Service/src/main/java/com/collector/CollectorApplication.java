package com.collector;



import java.util.Collections;

import javax.annotation.Resource;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.collector.service.FilesStorageService;

@SpringBootApplication
public class CollectorApplication implements CommandLineRunner {
  @Resource
  FilesStorageService storageService;

  public static void main(String[] args) {
		SpringApplication app = new SpringApplication(CollectorApplication.class);
        app.setDefaultProperties(Collections
                .singletonMap("server.port", "8080"));
              app.run(args);
  }

  @Override
  public void run(String... arg) throws Exception {
    storageService.deleteAll();
    storageService.init();
  }
}
