package com.collector.service;
import java.util.UUID; 
public class UuidCreator {
	   
	public UUID getUUID()     
	{    
	//generates random UUID   for each file to store in filestore 
	UUID uuid=UUID.randomUUID();   
	System.out.println(uuid);
	return uuid;    
	}    
}
